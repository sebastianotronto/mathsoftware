x = int(input("Input something: "))

A = [1,2,3]

for i in range(2,9):
	z = 10**i
	print("A power of 10:", z)
	
print("Bye")

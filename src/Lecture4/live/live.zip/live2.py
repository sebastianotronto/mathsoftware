x = int(input("Input something: "))

while x > 10:
	print("Large number!", x)
	x = x - 1
	
print("Bye")

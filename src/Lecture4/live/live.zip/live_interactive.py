2+2
3*5
3/5
3 // 5
2.5 + (456 - 0.3)
2 ** 10
13 // 5
13 % 5
sqrt(3)
import math
sqrt(3)
math.sqrt(3)
help()
math
asfdads
2+2
help("import")
sqrt(10)
math.sqrt(10)
from math import *
sqrt(10)
10 - _
_
x = 10 + sqrt(3)
x
abc_3 = 45+3*(2-1.4)
abc_3
x / (abc_3+2)
x
x = 3*abc_3
x
abc_3 = 0
abc_3
x
1 = 1
1 == 1
1 == 3
x
type(x)
abc_3
type(abc_3)
type(3/2)
type(3/1)
3/1
type(1 == 1)
y = False
z = (2 == 2)
y
z
type(z)
type(y)
y and z
True and True
y or z
not True
3 >= 4
3 >= 3
3 > 3
3 != 4
hello
"hello"
type("hello")
st = "Hello, World!"
st
type(st)
len(st)
"hello" + ", world"
"abc" + "abc"
2 * "abc"
10 * "abc"
"hello" * "abc"
True + False
[1,2,3,1,-1.5]
[1,True,"hello"]
L = [1,True,"hello"]
type(L)
{1,2,3,1,-1.5}
{12, 25, 10, -1}
len(L)
len({1,1,1})
{1,1,1}
1 in L
-42 in L
1.5 in {2,3.1,1.5}
S = {-2, 0, 10, 25}
max(S)
min(S)
sum(S)
sum([10,2,45])
L
min(L)
L2 = [1,2, 1, -2, 0, 2]
set(L2)
list({1,2,1,3,-2})
S
list(S)
[x**2 for x in [-1,4,1,0] if x < 3]
{x**2 for x in [-1,4,1,0] if x < 3}
{x+2 for x in [-1,4,1,0] if x < 3}
{x+2 for x in {-1,4,1,0} if x < 3}
[x+2 for x in {-1,4,1,0} if x < 3]
[x+2 for x in {-1,4,1,0} if True]
[x+2 for x in {-1,4,1,0}]
[x+2 for x in {-1,4,1,0} if x+10-3.24 < x^2]
[i*j for i in [0,1,2,3] for j in {-1,1}]
range(0,4)
type(range(0,4))
[i*j for i in range(0,4) for j in {-1,1}]
list(range(0,4))
list(range(3,4))
list(range(3,10))
list(range(10))
list(range(1,10,2))
list(range(10,1,-1))
L
L[0]
L[1]
L[2]
L[10]
L[-1]
L[len(L)-1]
L[len(L)-3]
L[-3]
L2
L[1:4]
L2[1:4]
L2[1:4:2]
R=range(10)
R
R=list(range(10))
R
R[2:8:2]
R[9:3:-1]
R
type(R)
R[3]
R[3] = 3.14
R
R.append(10)
R
R.insert(3,3.0)
R
R[3]
del R[4]
R
L
R
L + R
L
R
L * 3
3 * L
S
type(S)
S.add(3)
S
S.add(10)
S
S.remove(25)
S
T = {3, -2, 27, 99}
{3, -2} < T
{3, -2} < S
S >= {3, -2}
S >= S
S > S
S | T
S & T
S - T
2+3
import readline
readline.write_history_file('live_interactive.py')
